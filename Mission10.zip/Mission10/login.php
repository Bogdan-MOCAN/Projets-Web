<?php
session_start();

// Inclusion du fichier de connexion à la base de données
require_once "connexion.php";

// Variable pour stocker les messages d'erreur
$error = "";

// Vérifie si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Récupère les valeurs du formulaire et supprime les espaces inutiles
    $login = trim($_POST["login"] ?? "");
    $password = trim($_POST["password"] ?? "");

    // Vérifie que les deux champs sont remplis
    if ($login && $password) {

        // Prépare la requête pour récupérer l'utilisateur correspondant à l'identifiant
        $stmt = $pdo->prepare("
            SELECT USER, MDP, TYPECOMPTE, NOMCPTE, PRENOMCPTE 
            FROM COMPTE 
            WHERE USER = :login 
            LIMIT 1
        ");

        // Exécute la requête avec le paramètre lié
        $stmt->execute([":login" => $login]);

        // Récupère la ligne correspondante (ou false si aucun utilisateur)
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifie que l'utilisateur existe et que le mot de passe correspond
        if ($user && password_verify($password, $user["MDP"])) {

            // Stocke les informations de l'utilisateur dans la session
            $_SESSION["user"]   = $user["USER"];
            $_SESSION["nom"]    = $user["NOMCPTE"];
            $_SESSION["prenom"] = $user["PRENOMCPTE"];
            $_SESSION["role"]   = $user["TYPECOMPTE"];

            // Redirige selon le rôle : GES -> page gestion, USG -> page vacancier
            header("Location: " . (
                $user["TYPECOMPTE"] === "GES" 
                ? "gestionnaire/hebergements_gestion.php" 
                : "usager/hebergements.php"
            ));
            exit; // Stoppe l'exécution après la redirection

        } else {
            // Mot de passe ou identifiant incorrect
            $error = "Identifiants incorrects.";
        }

    } else {
        // Un ou plusieurs champs vides
        $error = "Veuillez remplir tous les champs.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - RESA</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="background"></div>
    <div class="login-container">
        <h1>Application RESA VVA</h1>
        <h2>Connexion</h2>

        <!-- Affiche le message d'erreur si défini -->
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Formulaire de connexion -->
        <form method="post">
            <label for="login">Identifiant</label>
            <input type="text" id="login" name="login" required>

            <label for="password">Mot de passe</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Se connecter</button>
        </form>

        <!-- Lien pour revenir à l'accueil -->
        <p class="home-link">
            ← <a href="index.php">Retour à l'accueil</a>
        </p>
    </div>
</body>
</html>
