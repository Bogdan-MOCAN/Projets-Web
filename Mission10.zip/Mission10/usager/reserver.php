<?php
session_start();
require_once "../connexion.php"; // connexion PDO

// Vérification accès vacancier
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'USG') {
    header("Location: ../login.php");
    exit;
}

// Vérifier l'ID de l'hébergement
$idHeb = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$idHeb) die("Hébergement invalide.");

// Charger les infos de l'hébergement
$stmt = $pdo->prepare("SELECT * FROM hebergement WHERE NOHEB = :id");
$stmt->execute(['id' => $idHeb]);
$heb = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$heb) die("Hébergement non trouvé.");

// Récupérer les semaines disponibles
$dates = $pdo->query("SELECT DATEDEBSEM FROM semaine ORDER BY DATEDEBSEM")->fetchAll(PDO::FETCH_COLUMN);

// Valeurs par défaut
$valeurs = [
    'nom' => '', 'prenom' => '', 'email' => '',
    'date_arrivee' => '', 'nb_personnes' => 1, 'cb_exemple' => ''
];
$message = "";

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($valeurs as $k => &$v) $v = trim($_POST[$k] ?? '');

    // Validation côté PHP
    if (in_array('', [$valeurs['nom'], $valeurs['prenom'], $valeurs['email'], $valeurs['date_arrivee']], true)) {
        $message = "Veuillez remplir tous les champs obligatoires.";
    } elseif (!filter_var($valeurs['email'], FILTER_VALIDATE_EMAIL)) {
        $message = "Adresse e-mail invalide.";
    } elseif (!in_array($valeurs['date_arrivee'], $dates)) {
        $message = "La date sélectionnée n'est pas valide.";
    } elseif ((int)$valeurs['nb_personnes'] < 1 || (int)$valeurs['nb_personnes'] > (int)$heb['NBPLACEHEB']) {
        $message = "Le nombre de personnes doit être compris entre 1 et {$heb['NBPLACEHEB']}.";
    } else {
        $user = $_SESSION['user'];
        $dateDebSem = $valeurs['date_arrivee'];
        $nb = (int)$valeurs['nb_personnes'];
        $tarif = (float)$heb['TARIFSEMHEB'];
        $arrhes = round($tarif * 0.3, 2);
        $noResa = (int)$pdo->query("SELECT IFNULL(MAX(NORESA), 0) + 1 FROM resa")->fetchColumn();

        try {
            $stmt = $pdo->prepare("
                INSERT INTO resa 
                (NORESA, USER, DATEDEBSEM, NOHEB, CODEETATRESA, DATERESA, DATEARRHES, MONTANTARRHES, NBOCCUPANT, TARIFSEMRESA)
                VALUES (:id, :user, :deb, :heb, 'EN', CURDATE(), :arrhesDate, :arrhes, :nb, :tarif)
            ");
            $stmt->execute([
                'id' => $noResa, 
                'user' => $user, 
                'deb' => $dateDebSem,
                'heb' => $idHeb, 
                'arrhesDate' => $dateDebSem,
                'arrhes' => $arrhes, 
                'nb' => $nb, 
                'tarif' => $tarif
            ]);
            $message = "Réservation enregistrée avec succès.";
            $valeurs = array_map(fn() => '', $valeurs);
        } catch (PDOException $e) {
            $message = "Erreur : " . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réserver - <?= htmlspecialchars($heb['NOMHEB']) ?></title>
    <link rel="stylesheet" href="reserver.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo"><a href="../index.php">RESA VVA - Vacancier</a></div>
    <ul class="nav-links">
        <li><a href="../index.php">Accueil</a></li>
        <li><a href="hebergements.php">Réserver</a></li>
        <li><a href="../logout.php">Déconnexion</a></li>
    </ul>
</nav>

<div class="hebergement-detail">
    <h1>Réserver : <?= htmlspecialchars($heb['NOMHEB']) ?></h1>

    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="post" class="heb-info" novalidate>
        <label>Nom :</label>
        <input name="nom" value="<?= htmlspecialchars($valeurs['nom']) ?>" required>

        <label>Prénom :</label>
        <input name="prenom" value="<?= htmlspecialchars($valeurs['prenom']) ?>" required>

        <label>Email :</label>
        <input type="email" name="email" value="<?= htmlspecialchars($valeurs['email']) ?>" required>

        <label>Semaine :</label>
        <select name="date_arrivee" required>
            <option value="">-- Sélectionnez --</option>
            <?php foreach ($dates as $d): ?>
                <option value="<?= htmlspecialchars($d) ?>" <?= $valeurs['date_arrivee'] === $d ? 'selected' : '' ?>>
                    <?= htmlspecialchars($d) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Personnes (max <?= htmlspecialchars($heb['NBPLACEHEB']) ?>) :</label>
        <input type="number" name="nb_personnes" 
               min="1" 
               max="<?= htmlspecialchars($heb['NBPLACEHEB']) ?>" 
               value="<?= htmlspecialchars($valeurs['nb_personnes']) ?>" 
               required>

        <label>Carte bancaire :</label>
        <input name="cb_exemple" placeholder="4111 1111 1111 1111" value="<?= htmlspecialchars($valeurs['cb_exemple']) ?>">

        <button type="submit" class="reserve-btn">Valider la réservation</button>
    </form>

    <div class="back-btn-wrapper">
        <a href="hebergements.php" class="back-btn">← Retour</a>
    </div>
</div>
</body>
</html>
