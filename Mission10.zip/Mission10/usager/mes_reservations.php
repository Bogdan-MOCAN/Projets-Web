<?php
session_start();
require_once "../connexion.php"; // connexion PDO

// Vérifier que l'utilisateur est connecté comme vacancier
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'USG') {
    header("Location: ../login.php");
    exit;
}

$user = $_SESSION['user'];

// Récupérer les réservations du vacancier
$sql = "
    SELECT h.NOMHEB, r.DATEDEBSEM, r.NBOCCUPANT, r.MONTANTARRHES, e.NOMETATRESA
    FROM resa r
    JOIN hebergement h ON r.NOHEB = h.NOHEB
    LEFT JOIN etat_resa e ON r.CODEETATRESA = e.CODEETATRESA
    WHERE r.USER = :user
    ORDER BY r.DATEDEBSEM ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute(['user' => $user]);
$reservations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Réservations</title>
    <link rel="stylesheet" href="mes_reservations.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo"><a href="hebergements.php">RESA VVA - Vacancier</a></div>
        <ul class="nav-links">
            <li><a href="hebergements.php">Accueil</a></li>
            <li><a href="../logout.php">Déconnexion</a></li>
        </ul>
    </nav>

    <div class="hebergement-detail">
        <h1>Mes Réservations</h1>

        <?php if (!$reservations): ?>
            <p class="message">Vous n'avez encore effectué aucune réservation.</p>
        <?php else: ?>
            <table class="reservation-table">
                <thead>
                    <tr>
                        <th>Hébergement</th>
                        <th>Semaine</th>
                        <th>Personnes</th>
                        <th>Arrhes (€)</th>
                        <th>État</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservations as $r): ?>
                        <tr>
                            <td><?= htmlspecialchars($r['NOMHEB']) ?></td>
                            <td><?= htmlspecialchars($r['DATEDEBSEM']) ?></td>
                            <td><?= htmlspecialchars($r['NBOCCUPANT']) ?></td>
                            <td><?= htmlspecialchars(number_format($r['MONTANTARRHES'], 2, ',', ' ')) ?></td>
                            <td><?= htmlspecialchars($r['NOMETATRESA'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="back-btn-wrapper">
            <a href="hebergements.php" class="back-btn">← Retour</a>
        </div>
    </div>
</body>
</html>
