<?php
session_start();
require_once "../connexion.php";

// Vérification que l'utilisateur est un vacancier (USG)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'USG') {
    header("Location: ../login.php");
    exit;
}

// Récupération des filtres depuis l'URL
$nb_places = $__GET['nb_places'] ?? '';
$type = $_GET['type'] ?? '';

// Récupération des types d'hébergement depuis la base
$types = $pdo->query("SELECT CODETYPEHEB, NOMTYPEHEB FROM type_heb ORDER BY NOMTYPEHEB")
             ->fetchAll(PDO::FETCH_ASSOC);

// Construction de la requête SQL de base
$sql = "SELECT * FROM hebergement h WHERE 1";
$params = [];

// Ajout du filtre sur le nombre de places si spécifié
if ($nb_places) {
    $sql .= " AND h.NBPLACEHEB = :nb_places";
    $params[':nb_places'] = $nb_places;
}

// Ajout du filtre sur le type si spécifié
if ($type) {
    $sql .= " AND h.CODETYPEHEB = :type";
    $params[':type'] = $type;
}

// Préparation et exécution de la requête
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

// Récupération des hébergements correspondant aux filtres
$hebergements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Hébergements - RESA VVA</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <!-- Barre de navigation -->
    <nav class="navbar">
        <div class="nav-logo"><a href="hebergements.php">RESA VVA - Vacancier</a></div>
        <ul class="nav-links">
            <li><a href="hebergements.php">Accueil</a></li>
            <li><a href="mes_reservations.php">Mes réservations</a></li>
            <li><a href="../logout.php">Déconnexion</a></li>
        </ul>
    </nav>

    <div class="hebergements-page">
        <h1>Réserver un hébergement</h1>

        <!-- Formulaire de filtre -->
        <form method="get" class="filter-form">
            <select name="nb_places">
                <option value="">Nombre de places</option>
                <?php for ($i = 1; $i <= 10; $i++): ?>
                    <option value="<?= $i ?>" <?= ($nb_places == $i) ? 'selected' : '' ?>><?= $i ?> place(s)</option>
                <?php endfor; ?>
            </select>

            <select name="type">
                <option value="">Type</option>
                <?php foreach ($types as $t): ?>
                    <option value="<?= htmlspecialchars($t['CODETYPEHEB']) ?>" <?= ($type == $t['CODETYPEHEB']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['NOMTYPEHEB']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Filtrer</button>
            <a href="hebergements.php" class="reset-btn">Réinitialiser</a>
        </form>

        <!-- Liste des hébergements -->
        <div class="hebergements-container">
            <?php if ($hebergements): foreach ($hebergements as $h): ?>
                <div class="hebergement-card">
                    <img src="../src/<?= htmlspecialchars($h['PHOTOHEB'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($h['NOMHEB']) ?>">
                    <h3><?= htmlspecialchars($h['NOMHEB']) ?></h3>
                    <p>Capacité : <?= htmlspecialchars($h['NBPLACEHEB']) ?> personnes</p>
                    <p>Surface : <?= htmlspecialchars($h['SURFACEHEB']) ?> m²</p>
                    <p>Internet : <?= $h['INTERNET'] ? 'Oui' : 'Non' ?></p>
                    <p>Orientation : <?= htmlspecialchars($h['ORIENTATIONHEB']) ?></p>
                    <p>État : <?= htmlspecialchars($h['ETATHEB']) ?></p>
                    <p>Tarif / semaine : <?= htmlspecialchars($h['TARIFSEMHEB']) ?> €</p>
                    <a href="../hebergement.php?id=<?= $h['NOHEB'] ?>" class="details-btn">Voir détails</a>
                </div>
            <?php endforeach; else: ?>
                <div style="background-color: #ffdddd; color: #a33; padding: 15px; border-radius: 8px; text-align: center; font-weight: bold;">
                    Aucun hébergement ne correspond à vos critères.
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
