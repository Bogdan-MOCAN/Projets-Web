<?php
session_start();
require_once "../connexion.php";

// Vérification du rôle
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'GES') {
    header("Location: ../login.php");
    exit;
}

// Vérification et récupération de l'ID
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: hebergements_gestion.php");
    exit;
}

// Charger les types et l’hébergement
$types = $pdo->query("SELECT CODETYPEHEB, NOMTYPEHEB FROM type_heb ORDER BY NOMTYPEHEB")
             ->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT * FROM hebergement WHERE NOHEB = ?");
$stmt->execute([$id]);
$heb = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$heb) {
    die("Hébergement introuvable.");
}

// Mise à jour si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'CODETYPEHEB'    => $_POST['CODETYPEHEB'] ?? '',
        'NOMHEB'         => trim($_POST['NOMHEB'] ?? ''),
        'NBPLACEHEB'     => (int)($_POST['NBPLACEHEB'] ?? 0),
        'SURFACEHEB'     => (float)($_POST['SURFACEHEB'] ?? 0),
        'INTERNET'       => isset($_POST['INTERNET']) ? 1 : 0,
        'ANNEEHEB'       => (int)($_POST['ANNEEHEB'] ?? 0),
        'SECTEURHEB'     => trim($_POST['SECTEURHEB'] ?? ''),
        'ORIENTATIONHEB' => trim($_POST['ORIENTATIONHEB'] ?? ''),
        'ETATHEB'        => trim($_POST['ETATHEB'] ?? ''),
        'DESCRIHEB'      => trim($_POST['DESCRIHEB'] ?? ''),
        'PHOTOHEB'       => trim($_POST['PHOTOHEB'] ?? ''),
        'TARIFSEMHEB'    => (float)($_POST['TARIFSEMHEB'] ?? 0),
        'NOHEB'          => $id
    ];

    $sql = "UPDATE hebergement SET
                CODETYPEHEB=:CODETYPEHEB, NOMHEB=:NOMHEB, NBPLACEHEB=:NBPLACEHEB,
                SURFACEHEB=:SURFACEHEB, INTERNET=:INTERNET, ANNEEHEB=:ANNEEHEB,
                SECTEURHEB=:SECTEURHEB, ORIENTATIONHEB=:ORIENTATIONHEB, ETATHEB=:ETATHEB,
                DESCRIHEB=:DESCRIHEB, PHOTOHEB=:PHOTOHEB, TARIFSEMHEB=:TARIFSEMHEB
            WHERE NOHEB=:NOHEB";

    $pdo->prepare($sql)->execute($data);
    header("Location: hebergements_gestion.php?success=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un Hébergement</title>
    <link rel="stylesheet" href="modifier.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo"><a href="hebergements_gestion.php">RESA VVA - Gestion</a></div>
    <ul class="nav-links">
        <li><a href="hebergements_gestion.php">Hébergements</a></li>
        <li><a href="reservations_gestion.php">Réservations</a></li>
        <li><a href="../logout.php">Déconnexion</a></li>
    </ul>
</nav>

<div class="form-page">
    <h1>Modifier l’hébergement</h1>

    <form method="post" class="heb-form">
        <label>Type :</label>
        <select name="CODETYPEHEB" required>
            <?php foreach($types as $t): ?>
                <option value="<?= $t['CODETYPEHEB'] ?>" <?= $t['CODETYPEHEB']===$heb['CODETYPEHEB']?'selected':'' ?>>
                    <?= htmlspecialchars($t['NOMTYPEHEB']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Nom :</label>
        <input type="text" name="NOMHEB" required value="<?= htmlspecialchars($heb['NOMHEB']) ?>">

        <label>Places :</label>
        <input type="number" name="NBPLACEHEB" required value="<?= htmlspecialchars($heb['NBPLACEHEB']) ?>">

        <label>Surface (m²) :</label>
        <input type="number" name="SURFACEHEB" value="<?= htmlspecialchars($heb['SURFACEHEB']) ?>">

        <label>Internet :</label>
        <input type="checkbox" name="INTERNET" <?= $heb['INTERNET'] ? 'checked' : '' ?>>

        <label>Année :</label>
        <input type="number" name="ANNEEHEB" value="<?= htmlspecialchars($heb['ANNEEHEB']) ?>">

        <label>Secteur :</label>
        <input type="text" name="SECTEURHEB" value="<?= htmlspecialchars($heb['SECTEURHEB']) ?>">

        <label>Orientation :</label>
        <input type="text" name="ORIENTATIONHEB" value="<?= htmlspecialchars($heb['ORIENTATIONHEB']) ?>">

        <label>État :</label>
        <input type="text" name="ETATHEB" value="<?= htmlspecialchars($heb['ETATHEB']) ?>">

        <label>Description :</label>
        <textarea name="DESCRIHEB"><?= htmlspecialchars($heb['DESCRIHEB']) ?></textarea>

        <label>Photo :</label>
        <input type="text" name="PHOTOHEB" value="<?= htmlspecialchars($heb['PHOTOHEB']) ?>">

        <label>Tarif (€ / semaine) :</label>
        <input type="number" step="0.01" name="TARIFSEMHEB" value="<?= htmlspecialchars($heb['TARIFSEMHEB']) ?>">

        <div class="form-actions">
            <button type="submit" class="reserve-btn">Enregistrer</button>
            <a href="hebergements_gestion.php" class="back-btn">Annuler</a>
        </div>
    </form>
</div>
</body>
</html>
