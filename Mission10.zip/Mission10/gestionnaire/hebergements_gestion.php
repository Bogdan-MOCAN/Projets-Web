<?php
session_start();
require_once "../connexion.php";

// Vérification du rôle
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'GES') {
    header("Location: ../login.php");
    exit;
}

// Filtre par type
$type = $_GET['type'] ?? '';

// Récupérer tous les types
$types = $pdo->query("SELECT CODETYPEHEB, NOMTYPEHEB FROM type_heb ORDER BY NOMTYPEHEB")
             ->fetchAll(PDO::FETCH_ASSOC);

// La requête principale
$sql = "SELECT * FROM hebergement WHERE 1";
$params = [];

if ($type) {
    $sql .= " AND CODETYPEHEB = :type";
    $params[':type'] = $type;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$hebergements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Hébergements - RESA VVA</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo"><a href="hebergements_gestion.php">RESA VVA - Gestion</a></div>
    <ul class="nav-links">
        <li><a href="hebergements_gestion.php">Hébergements</a></li>
        <li><a href="reservations_gestion.php">Réservations</a></li>
        <li><a href="../logout.php">Déconnexion</a></li>
    </ul>
</nav>

<div class="hebergements-page">
    <h1>Gestion des hébergements</h1>

    <!-- Filtres -->
    <form method="get" class="filter-form">
        <select name="type">
            <option value="">Tous les types</option>
            <?php foreach($types as $t): ?>
                <option value="<?= htmlspecialchars($t['CODETYPEHEB']) ?>" <?= $type===$t['CODETYPEHEB']?'selected':'' ?>>
                    <?= htmlspecialchars($t['NOMTYPEHEB']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Filtrer</button>
        <a href="hebergements_gestion.php" class="reset-btn">Réinitialiser</a>
    </form>

    <!-- Bouton d'ajout -->
    <div class="action-btns">
        <a href="ajout_hebergement.php" class="add-btn">+ Ajouter un hébergement</a>
    </div>

    <!-- Liste des hébergements -->
    <div class="hebergements-container">
        <?php if ($hebergements): ?>
            <?php foreach ($hebergements as $h): ?>
                <div class="hebergement-card">
                    <img src="../src/<?= htmlspecialchars($h['PHOTOHEB'] ?: 'default.jpg') ?>" 
                         alt="<?= htmlspecialchars($h['NOMHEB']) ?>">
                    <h3><?= htmlspecialchars($h['NOMHEB']) ?></h3>
                    <p>Capacité : <?= htmlspecialchars($h['NBPLACEHEB']) ?> pers</p>
                    <p>Surface : <?= htmlspecialchars($h['SURFACEHEB']) ?> m²</p>
                    <p>Internet : <?= $h['INTERNET'] ? 'Oui' : 'Non' ?></p>
                    <p>Orientation : <?= htmlspecialchars($h['ORIENTATIONHEB']) ?></p>
                    <p>Tarif : <?= htmlspecialchars($h['TARIFSEMHEB']) ?> € / sem</p>

                    <div class="gestion-btns">
                        <a href="modifier_hebergement.php?id=<?= $h['NOHEB'] ?>" class="details-btn">Modifier</a>
                        <a href="supprimer_hebergement.php?id=<?= $h['NOHEB'] ?>" 
                           class="back-btn" 
                           onclick="return confirm('Supprimer cet hébergement ?');">Supprimer</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="background-color: #fffae6; color: #b36d00; padding: 15px; border-radius: 8px; text-align: center; font-weight: bold;">
                Aucun hébergement trouvé.
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
