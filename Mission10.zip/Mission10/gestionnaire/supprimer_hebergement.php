<?php
session_start();
require_once "../connexion.php";

// Vérification : connecté + rôle gestionnaire
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'GES') {
    header("Location: ../login.php");
    exit;
}

// Vérification de l'ID
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: hebergements_gestion.php");
    exit;
}

// Suppression sécurisée
$pdo->prepare("DELETE FROM hebergement WHERE NOHEB = :id")->execute(['id' => $id]);

// Redirection après suppression
header("Location: hebergements_gestion.php?deleted=1");
exit;
?>