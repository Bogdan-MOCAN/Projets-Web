<?php
session_start();
require_once "../connexion.php";

// Accès réservé au gestionnaire
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'GES') {
    header("Location: ../login.php");
    exit;
}

// Récupération des types
$types = $pdo->query("SELECT CODETYPEHEB, NOMTYPEHEB FROM type_heb ORDER BY NOMTYPEHEB")
             ->fetchAll(PDO::FETCH_ASSOC);

// Si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Générer un nouvel ID
    $newId = ($pdo->query("SELECT MAX(NOHEB) FROM hebergement")->fetchColumn() ?? 0) + 1;

    // Données à insérer
    $data = [
        'NOHEB'          => $newId,
        'CODETYPEHEB'    => $_POST['CODETYPEHEB'],
        'NOMHEB'         => $_POST['NOMHEB'],
        'NBPLACEHEB'     => $_POST['NBPLACEHEB'],
        'SURFACEHEB'     => $_POST['SURFACEHEB'] ?: null,
        'INTERNET'       => isset($_POST['INTERNET']) ? 1 : 0,
        'ANNEEHEB'       => $_POST['ANNEEHEB'] ?: null,
        'SECTEURHEB'     => $_POST['SECTEURHEB'] ?: null,
        'ORIENTATIONHEB' => $_POST['ORIENTATIONHEB'] ?: null,
        'ETATHEB'        => $_POST['ETATHEB'] ?: null,
        'DESCRIHEB'      => $_POST['DESCRIHEB'] ?: null,
        'PHOTOHEB'       => $_POST['PHOTOHEB'] ?: 'default.jpg',
        'TARIFSEMHEB'    => $_POST['TARIFSEMHEB'] ?: 0
    ];

    // Insertion
    $stmt = $pdo->prepare("
        INSERT INTO hebergement 
        (NOHEB, CODETYPEHEB, NOMHEB, NBPLACEHEB, SURFACEHEB, INTERNET, ANNEEHEB, SECTEURHEB, ORIENTATIONHEB, ETATHEB, DESCRIHEB, PHOTOHEB, TARIFSEMHEB)
        VALUES
        (:NOHEB, :CODETYPEHEB, :NOMHEB, :NBPLACEHEB, :SURFACEHEB, :INTERNET, :ANNEEHEB, :SECTEURHEB, :ORIENTATIONHEB, :ETATHEB, :DESCRIHEB, :PHOTOHEB, :TARIFSEMHEB)
    ");
    $stmt->execute($data);

    // Redirection
    header("Location: hebergements_gestion.php?added=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un hébergement</title>
    <link rel="stylesheet" href="modifier.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo"><a href="hebergements_gestion.php">RESA VVA - Gestion</a></div>
    <ul class="nav-links">
        <li><a href="hebergements_gestion.php">Hébergements</a></li>
        <li><a href="reservations_gestion.php">Réservations</a></li>
        <li><a href="../logout.php">Déconnexion</a></li>
    </ul>
</nav>

<div class="form-page">
    <h1>Ajouter un hébergement</h1>

    <form method="post" class="heb-form">
        <label>Type :</label>
        <select name="CODETYPEHEB" required>
            <option value="">-- Choisir un type --</option>
            <?php foreach ($types as $t): ?>
                <option value="<?= htmlspecialchars($t['CODETYPEHEB']) ?>">
                    <?= htmlspecialchars($t['NOMTYPEHEB']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Nom :</label>
        <input type="text" name="NOMHEB" required>

        <label>Nombre de places :</label>
        <input type="number" name="NBPLACEHEB" required>

        <label>Surface (m²) :</label>
        <input type="number" name="SURFACEHEB">

        <label><input type="checkbox" name="INTERNET"> Internet disponible</label>

        <label>Année :</label>
        <input type="number" name="ANNEEHEB">

        <label>Secteur :</label>
        <input type="text" name="SECTEURHEB">

        <label>Orientation :</label>
        <input type="text" name="ORIENTATIONHEB">

        <label>État :</label>
        <input type="text" name="ETATHEB">

        <label>Description :</label>
        <textarea name="DESCRIHEB"></textarea>

        <label>Photo (nom du fichier) :</label>
        <input type="text" name="PHOTOHEB">

        <label>Tarif / semaine (€) :</label>
        <input type="number" step="0.01" name="TARIFSEMHEB">

        <div class="form-actions">
            <button type="submit" class="reserve-btn">Ajouter</button>
            <a href="hebergements_gestion.php" class="back-btn">Annuler</a>
        </div>
    </form>
</div>
</body>
</html>
