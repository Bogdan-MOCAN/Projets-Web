<?php
session_start();
require_once "../connexion.php";

// Vérif rôle gestionnaire
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'GES') {
    header("Location: ../login.php");
    exit;
}

// Mise à jour de l'état d'une réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['res_id']) && !empty($_POST['etat'])) {
    $resId = (int)$_POST['res_id'];
    $etat  = $_POST['etat'];

    // Récupérer les infos actuelles
    $old = $pdo->prepare("SELECT NOHEB FROM resa WHERE NORESA = :id");
    $old->execute(['id' => $resId]);
    $noHeb = $old->fetchColumn();

    if ($noHeb) {
        // Mise à jour de l'état
        $pdo->prepare("UPDATE resa SET CODEETATRESA = :etat WHERE NORESA = :id")
            ->execute(['etat' => $etat, 'id' => $resId]);

        // Mettre à jour le nom de l’hébergement
        $nom = $pdo->prepare("SELECT NOMHEB FROM hebergement WHERE NOHEB = :noheb");
        $nom->execute(['noheb' => $noHeb]);
        $nomActuel = $nom->fetchColumn();

        if ($etat === 'CF' && strpos($nomActuel, ' - Réservé') === false) {
            $pdo->prepare("UPDATE hebergement SET NOMHEB = CONCAT(NOMHEB, ' - Réservé') WHERE NOHEB = :noheb")
                ->execute(['noheb' => $noHeb]);
        } elseif ($etat !== 'CF' && strpos($nomActuel, ' - Réservé') !== false) {
            $pdo->prepare("UPDATE hebergement SET NOMHEB = REPLACE(NOMHEB, ' - Réservé', '') WHERE NOHEB = :noheb")
                ->execute(['noheb' => $noHeb]);
        }

        header("Location: reservations_gestion.php?updated=1");
        exit;
    }
}

// Récupérer les réservations
$reservations = $pdo->query("
    SELECT r.NORESA, r.NOHEB, r.USER, r.DATEDEBSEM, r.DATEARRHES, r.MONTANTARRHES, r.NBOCCUPANT, r.CODEETATRESA,
           h.NOMHEB, h.CODETYPEHEB, e.NOMETATRESA
    FROM resa r
    JOIN hebergement h ON r.NOHEB = h.NOHEB
    JOIN etat_resa e ON r.CODEETATRESA = e.CODEETATRESA
    ORDER BY r.DATEDEBSEM DESC
")->fetchAll(PDO::FETCH_ASSOC);

// États possibles
$etats = $pdo->query("SELECT CODEETATRESA, NOMETATRESA FROM etat_resa")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Réservations</title>
    <link rel="stylesheet" href="reservation.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo"><a href="hebergements_gestion.php">RESA VVA - Gestion</a></div>
    <ul class="nav-links">
        <li><a href="hebergements_gestion.php">Hébergements</a></li>
        <li><a href="reservations_gestion.php">Réservations</a></li>
        <li><a href="../logout.php">Déconnexion</a></li>
    </ul>
</nav>

<div class="hebergements-page">
    <h1>Gestion des réservations</h1>

    <?php if(isset($_GET['updated'])): ?>
        <p class="message">État de la réservation mis à jour !</p>
    <?php endif; ?>

    <?php if($reservations): ?>
        <div class="hebergements-container">
            <?php foreach($reservations as $r): ?>
                <div class="hebergement-card">
                    <h3><?= htmlspecialchars($r['NOMHEB']) ?> (<?= htmlspecialchars($r['CODETYPEHEB']) ?>)</h3>
                    <p>Vacancier : <?= htmlspecialchars($r['USER']) ?></p>
                    <p>Date : <?= htmlspecialchars($r['DATEDEBSEM']) ?></p>

                    <form method="post" class="heb-info">
                        <input type="hidden" name="res_id" value="<?= $r['NORESA'] ?>">
                        <select name="etat" onchange="this.form.submit()">
                            <?php foreach($etats as $e): ?>
                                <option value="<?= $e['CODEETATRESA'] ?>" <?= $r['CODEETATRESA'] === $e['CODEETATRESA'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($e['NOMETATRESA']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Aucune réservation pour le moment.</p>
    <?php endif; ?>
</div>
</body>
</html>
