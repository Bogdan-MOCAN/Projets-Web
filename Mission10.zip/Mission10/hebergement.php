<?php
session_start();
require_once "connexion.php";

// Vérifier que l'ID est valide
$id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : die("Hébergement invalide.");

// Récupérer l'hébergement avec le nom du type via JOIN
$stmt = $pdo->prepare("
    SELECT h.*, t.NOMTYPEHEB
    FROM hebergement h
    LEFT JOIN type_heb t ON h.CODETYPEHEB = t.CODETYPEHEB
    WHERE h.NOHEB = ?
");
$stmt->execute([$id]);
$heb = $stmt->fetch(PDO::FETCH_ASSOC) ?: die("Hébergement non trouvé.");

// Récupérer le rôle si connecté
$role = $_SESSION['role'] ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($heb['NOMHEB']) ?> - RESA VVA</title>
    <link rel="stylesheet" href="hebergement.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-logo"><a href="index.php">RESA VVA</a></div>
    <ul class="nav-links">
        <li><a href="index.php">Accueil</a></li>
        <?php
        if ($role === 'USG') {
            echo '<li><a href="usager/mes_reservations.php">Mes réservations</a></li>
                  <li><a href="logout.php">Déconnexion</a></li>';
        } elseif ($role === 'GES') {
            echo '<li><a href="gestionnaire/reservations.php">Gestion des réservations</a></li>
                  <li><a href="gestionnaire/hebergements_gestion.php">Gérer les hébergements</a></li>
                  <li><a href="logout.php">Déconnexion</a></li>';
        } else {
            echo '<li><a href="login.php">Connexion</a></li>
                  <li><a href="register.php">Inscription</a></li>';
        }
        ?>
    </ul>
</nav>

<div class="hebergement-detail">
    <h1><?= htmlspecialchars($heb['NOMHEB']) ?></h1>
    <div class="heb-container">
        <div class="heb-image">
            <img src="src/<?= htmlspecialchars($heb['PHOTOHEB'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($heb['NOMHEB']) ?>">
        </div>
        <div class="heb-info">
            <p><strong>Type :</strong> <?= htmlspecialchars($heb['NOMTYPEHEB'] ?? 'Non défini') ?></p>
            <p><strong>Capacité :</strong> <?= htmlspecialchars($heb['NBPLACEHEB']) ?> personnes</p>
            <p><strong>Surface :</strong> <?= htmlspecialchars($heb['SURFACEHEB']) ?> m²</p>
            <p><strong>Internet :</strong> <?= $heb['INTERNET'] ? 'Oui' : 'Non' ?></p>
            <p><strong>Orientation :</strong> <?= htmlspecialchars($heb['ORIENTATIONHEB']) ?></p>
            <p><strong>État :</strong> <?= htmlspecialchars($heb['ETATHEB']) ?></p>
            <p><strong>Année :</strong> <?= htmlspecialchars($heb['ANNEEHEB']) ?></p>
            <p><strong>Secteur :</strong> <?= htmlspecialchars($heb['SECTEURHEB']) ?></p>
            <p><strong>Description :</strong> <?= nl2br(htmlspecialchars($heb['DESCRIHEB'])) ?></p>
            <p><strong>Tarif / semaine :</strong> <?= htmlspecialchars($heb['TARIFSEMHEB']) ?> €</p>

            <?php if ($role === 'USG'): ?>
                <a href="usager/reserver.php?id=<?= $heb['NOHEB'] ?>" class="reserve-btn">Réserver</a>
            <?php endif; ?>
            <button class="back-btn" onclick="window.history.back()">← Retour</button>
        </div>
    </div>
</div>
</body>
</html>
