<?php
session_start();

// Vider toutes les variables de session
$_SESSION = [];

// Détruire la session côté serveur
session_destroy();

// Rediriger vers l'accueil
header("Location: index.php");
exit;
