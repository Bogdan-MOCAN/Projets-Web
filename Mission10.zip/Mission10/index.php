<?php
session_start();
require_once "connexion.php";

// Récupération des filtres depuis l'URL
$nb_places = $_GET['nb_places'] ?? '';
$type = $_GET['type'] ?? '';

// Récupération des types d'hébergement depuis la base
$types = $pdo->query("SELECT CODETYPEHEB, NOMTYPEHEB FROM type_heb ORDER BY NOMTYPEHEB")
             ->fetchAll(PDO::FETCH_ASSOC);

// Requête de base pour récupérer les hébergements
$sql = "SELECT * FROM hebergement WHERE 1";
$params = [];

// Filtrage par nombre de places si spécifié
if ($nb_places) {
    $sql .= " AND NBPLACEHEB = :nb_places";
    $params[':nb_places'] = $nb_places;
}

// Filtrage par type si spécifié
if ($type) {
    $sql .= " AND CODETYPEHEB = :type";
    $params[':type'] = $type;
}

// Préparation et exécution de la requête
$hebergements = $pdo->prepare($sql);
$hebergements->execute($params);
$hebergements = $hebergements->fetchAll(PDO::FETCH_ASSOC);

// Récupération du rôle de l'utilisateur connecté (si connecté)
$role = $_SESSION['role'] ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil - RESA VVA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Barre de navigation -->
    <nav class="navbar">
        <div class="nav-logo"><a href="index.php">RESA VVA</a></div>
        <ul class="nav-links">
            <li><a href="index.php">Accueil</a></li>
            <li><a href="login.php">Connexion</a></li>
        </ul>
    </nav>

    <div class="hebergements-page">
        <h1>Liste des hébergements</h1>

        <!-- Formulaire de filtrage -->
        <form method="get" class="filter-form">
            <select name="nb_places">
                <option value="">Nombre de places</option>
                <?php for ($i = 1; $i <= 10; $i++): ?>
                    <option value="<?= $i ?>" <?= ($nb_places == $i) ? 'selected' : '' ?>><?= $i ?> place(s)</option>
                <?php endfor; ?>
            </select>

            <select name="type">
                <option value="">Type</option>
                <?php foreach ($types as $t): ?>
                    <option value="<?= htmlspecialchars($t['CODETYPEHEB']) ?>" <?= ($type == $t['CODETYPEHEB']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['NOMTYPEHEB']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Filtrer</button>
            <a href="index.php" class="reset-btn">Réinitialiser</a>
        </form>

        <!-- Liste des hébergements -->
        <div class="hebergements-container">
            <?php if ($hebergements): ?>
                <?php foreach ($hebergements as $h): ?>
                    <div class="hebergement-card">
                        <img src="src/<?= htmlspecialchars($h['PHOTOHEB'] ?? 'default.jpg') ?>" alt="<?= htmlspecialchars($h['NOMHEB']) ?>">
                        <h3><?= htmlspecialchars($h['NOMHEB']) ?></h3>
                        <p>Capacité : <?= htmlspecialchars($h['NBPLACEHEB']) ?> personnes</p>
                        <p>Surface : <?= htmlspecialchars($h['SURFACEHEB']) ?> m²</p>
                        <p>Internet : <?= $h['INTERNET'] ? 'Oui' : 'Non' ?></p>
                        <p>Orientation : <?= htmlspecialchars($h['ORIENTATIONHEB']) ?></p>
                        <p>État : <?= htmlspecialchars($h['ETATHEB']) ?></p>
                        <p>Tarif / semaine : <?= htmlspecialchars($h['TARIFSEMHEB']) ?> €</p>
                        <a href="hebergement.php?id=<?= $h['NOHEB'] ?>">Voir détails</a>    
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="background-color: #fffae6; color: #b36d00; padding: 15px; border-radius: 8px; text-align: center; font-weight: bold;">
                    Aucun hébergement ne correspond à vos critères.
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
