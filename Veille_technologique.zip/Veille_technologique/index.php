<?php
require_once "connexion.php";

/* =============================
   FLUX RSS NVIDIA / GPU
============================= */
$rss_url = "https://www.tomshardware.com/feeds/tag/gpu";

/* =============================
   IMPORT RSS
============================= */
$rss = @simplexml_load_file($rss_url);

if ($rss) {
    foreach ($rss->channel->item as $item) {
        $titre = (string)$item->title;
        $resume = strip_tags((string)$item->description);
        $lien = (string)$item->link;
        $date_publication = date('Y-m-d', strtotime((string)$item->pubDate));
        $source = "Tom's Hardware";
        $categorie = "Cartes graphiques NVIDIA";

        // Récupération image si disponible
        $namespaces = $item->getNameSpaces(true);
        $image = '';
        if(isset($namespaces['media'])){
            $media = $item->children($namespaces['media']);
            if(isset($media->content) && isset($media->content->attributes()->url)){
                $image = (string)$media->content->attributes()->url;
            }
        }

        // Vérifie si l'article existe déjà
        $check = $pdo->prepare("SELECT id FROM articles WHERE lien = ?");
        $check->execute([$lien]);

        if ($check->rowCount() === 0) {
            $insert = $pdo->prepare("
                INSERT INTO articles 
                (titre, resume, lien, source, categorie, date_publication, image)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $insert->execute([
                $titre,
                $resume,
                $lien,
                $source,
                $categorie,
                $date_publication,
                $image
            ]);
        }
    }
}

/* =============================
   AFFICHAGE
============================= */
$articles = $pdo->query("
    SELECT * FROM articles 
    ORDER BY date_publication DESC 
    LIMIT 33
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Veille technologique – NVIDIA - MOCAN Bogdan</title>

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- CSS perso -->
    <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gradient-to-br from-gray-100 to-gray-200 min-h-screen">

<main class="max-w-7xl mx-auto px-4 py-12">

    <!-- HEADER -->
    <header class="text-center mb-20 fade-in">
        <span class="inline-block mb-4 px-4 py-1 rounded-full bg-green-100 text-green-700 text-sm font-semibold">
            Veille technologique automatisée - MOCAN Bogdan
        </span>

        <h1 class="text-4xl md:text-6xl font-extrabold text-green-600 mb-6 tracking-tight">
            NVIDIA – Cartes graphiques
        </h1>

        <p class="text-gray-600 max-w-3xl mx-auto mb-6 text-lg">
            Suivi automatisé des dernières actualités liées aux
            <strong>cartes graphiques NVIDIA</strong> à partir de sources
            spécialisées du matériel informatique.
        </p>

        <div class="flex justify-center gap-4 flex-wrap">
            <a href="explication.html"
               class="inline-flex items-center gap-2 bg-white px-6 py-3 rounded-full
                      text-blue-600 font-medium shadow-md hover:shadow-lg transition">
                📄 Explication de la veille
            </a>

            <a href="index.php"
            class="inline-flex items-center gap-2 bg-green-600 px-6 py-3 rounded-full
                    text-white font-medium shadow-md hover:bg-green-700 transition">
                ← Retour
            </a>
        </div>
    </header>

    <!-- ARTICLES -->
    <section id="articles"
             class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-10">

        <?php foreach ($articles as $article): ?>
            <article class="group bg-white rounded-2xl shadow-md overflow-hidden
                            hover:shadow-xl transition flex flex-col">

                <!-- Image -->
                <?php if(!empty($article['image'])): ?>
                    <div class="overflow-hidden">
                        <img src="<?= htmlspecialchars($article['image']) ?>"
                             alt="<?= htmlspecialchars($article['titre']) ?>"
                             class="w-full h-48 object-cover group-hover:scale-105 transition duration-300">
                    </div>
                <?php endif; ?>

                <!-- Contenu -->
                <div class="p-6 flex-1 flex flex-col">

                    <span class="text-xs uppercase tracking-wide text-green-600 font-semibold mb-2">
                        <?= htmlspecialchars($article['categorie']) ?>
                    </span>

                    <h2 class="article-title text-xl font-bold mb-3 text-gray-800">
                        <?= htmlspecialchars($article['titre']) ?>
                    </h2>

                    <p class="article-resume text-gray-700 flex-1 mb-6 leading-relaxed">
                        <?= htmlspecialchars($article['resume']) ?>
                    </p>

                    <div class="flex justify-between items-center text-sm text-gray-500">
                        <span>
                            <?= htmlspecialchars($article['source']) ?> •
                            <?= date('d/m/Y', strtotime($article['date_publication'])) ?>
                        </span>

                        <a href="<?= $article['lien'] ?>"
                           target="_blank"
                           class="text-blue-600 font-medium hover:underline">
                            Lire →
                        </a>
                    </div>
                </div>

            </article>
        <?php endforeach; ?>

    </section>

</main>

<!-- =============================
     TRADUCTION AUTOMATIQUE JS
============================= -->
<script>
document.addEventListener("DOMContentLoaded", () => {
    const googleTranslateUrl =
        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=fr&dt=t&q=";

    const elements = document.querySelectorAll(".article-title, .article-resume");

    elements.forEach(el => {
        const texteOriginal = el.innerText;
        fetch(googleTranslateUrl + encodeURIComponent(texteOriginal))
            .then(res => res.json())
            .then(data => {
                if (data?.[0]?.[0]?.[0]) {
                    el.innerText = data[0][0][0];
                }
            })
            .catch(() => {});
    });
});
</script>

</body>
</html>
