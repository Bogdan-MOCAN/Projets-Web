<?php
$conn=mysqli_connect("localhost", "root", "", "bibliotheque");
echo "Parfait, connexion reussie";
?>