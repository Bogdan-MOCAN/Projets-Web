<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lenergy' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '');

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '9%yf}Oz%`~/;TBu2?7nkXO%<gZU>.%@FaSZ_wL`~N|&0>6y#djK>By7y=JtWhU6R' );
define( 'SECURE_AUTH_KEY',   'Zep=TupLx|!,wJGW1 =R2w<E<47KiWe53ubbM,=)&eK@LsF=PeoAu=+%`W$e%oU&' );
define( 'LOGGED_IN_KEY',     '0T`.eDFxj(Jll58WM~(f!-n!r((ce2C ;W|.8:ee_#m){}6UC*mt0^>_O|;DA=HT' );
define( 'NONCE_KEY',         'Hom@3BX]^YW`aE$()j!,R$3s.d}/vMEI[}X>;IdckM[5bBQl@]dx@uf7V)d@}80_' );
define( 'AUTH_SALT',         ':]$Z?3-U^/O9yNtiqFV}9St<jOisrf9/ y(]X+z%19MpnuIqm%)1Z,S +HQ|a,Oq' );
define( 'SECURE_AUTH_SALT',  'GLp*2xU&,hc.zb%gX^^LU5GtW^W$4^}tHFXH~U</P~EDgEfmTl;`g~(H /g:1thK' );
define( 'LOGGED_IN_SALT',    '!fG>1>wxgAwa.>4^C4R*|#gQ838R$j_SXF|YJQY?@k:ostO:,,#VCA+v&,EJ1937' );
define( 'NONCE_SALT',        'V2]*+-LxQT!YVcFVjbf}Ct)$4C-QmvB&&d{p[xmc6Un[-8yDMT-LDxCVLn(_xMc_' );
define( 'WP_CACHE_KEY_SALT', ').u(x/n<L-CjG/]m+>f si_nJ[e5}<,]1MA+Y{]357p[bv#SoEtz$PA6NGAfh|oH' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */
define('WP_HOME','http://localhost/lenergy-wp');
define('WP_SITEURL','http://localhost/lenergy-wp');

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

// define('WP_CACHE', true);
define('DISABLE_WP_CRON', true);

// WordPress update method
define('FS_METHOD', 'direct');

// WordPress update policy
define('AUTOMATIC_UPDATER_DISABLED', false);
define('WP_AUTO_UPDATE_CORE', 'minor');

// Workaround wp-cli issue with unset HTTP_HOST
// For more info  see https://github.com/wp-cli/wp-cli/issues/2431 &/or
// https://make.wordpress.org/cli/handbook/common-issues/#php-notice-undefined-index-on-_server-superglobal
if ( defined( 'WP_CLI' ) && WP_CLI && ! isset( $_SERVER['HTTP_HOST'] ) ) {
    $_SERVER['HTTP_HOST'] = 'localhost';
}
